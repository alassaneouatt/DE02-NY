sqoop job --meta-connect jdbc:hsqldb:hsql://sandbox.hortonworks.com:16000/sqoop --create branch_newData -- import --connect jdbc:mysql://localhost/CDW_SAPP --driver com.mysql.jdbc.Driver --query "SELECT BRANCH_CODE, BRANCH_NAME, BRANCH_STREET, BRANCH_CITY, BRANCH_STATE, CASE WHEN BRANCH_ZIP is null then 999999 ELSE BRANCH_ZIP END AS BRANCH_ZIP, CONCAT('(',RIGHT(BRANCH_PHONE,3),')', MID(BRANCH_PHONE,4,3),'-', LEFT(BRANCH_PHONE,4)) AS BRANCH_PHONE, LAST_UPDATED FROM CDW_SAPP_BRANCH WHERE \$CONDITIONS" -m 1 --incremental lastmodified --target-dir /user/Credit_Card_System/CDW_SAPP_BRANCH/ --check-column LAST_UPDATED --last-value 2018-06-04 --merge-key BRANCH_CODE --fields-terminated-by ','

sqoop job --meta-connect jdbc:hsqldb:hsql://sandbox.hortonworks.com:16000/sqoop --create customer_newData -- import --connect jdbc:mysql://localhost/CDW_SAPP --driver com.mysql.jdbc.Driver --query "SELECT CAST(SSN AS UNSIGNED INTEGER) AS SSN, CONCAT(UPPER(LEFT(FIRST_NAME,1)), LOWER(SUBSTRING(FIRST_NAME,2))) AS FIRST_NAME,
LOWER(MIDDLE_NAME) AS MIDDLE_NAME, CONCAT(UPPER(LEFT(LAST_NAME,1)), LOWER(SUBSTRING(LAST_NAME,2))) AS LAST_NAME,
CREDIT_CARD_NO, CONCAT(APT_NO,',', STREET_NAME) AS STREET_NAME_APT_NO,
CUST_CITY, CUST_STATE, CUST_COUNTRY, CAST(CUST_ZIP AS UNSIGNED INTEGER) AS CUST_ZIP, CONCAT(RIGHT(CUST_PHONE,3),'-', MID(CUST_PHONE,4,4)) AS CUST_PHONE,
CUST_EMAIL, LAST_UPDATED FROM CDW_SAPP_CUSTOMER WHERE \$CONDITIONS" -m 1 --incremental lastmodified --target-dir /user/Credit_Card_System/CDW_SAPP_CUSTOMER/ --check-column LAST_UPDATED --last-value 2018-06-04 --merge-key SSN,CREDIT_CARD_NO --fields-terminated-by '\t'

sqoop job --meta-connect jdbc:hsqldb:hsql://sandbox.hortonworks.com:16000/sqoop --create creditcard_newData -- import --connect jdbc:mysql://localhost/CDW_SAPP --driver com.mysql.jdbc.Driver --query "SELECT CREDIT_CARD_NO, CONCAT(YEAR, LPAD(MONTH,2,0),LPAD(DAY,2,0) ) AS TIMEID,
CUST_SSN, BRANCH_CODE, TRANSACTION_TYPE, TRANSACTION_VALUE, TRANSACTION_ID FROM CDW_SAPP_CREDITCARD WHERE \$CONDITIONS" -m 1 --incremental append --target-dir /user/Credit_Card_System/CDW_SAPP_CREDITCARD/ --check-column TRANSACTION_ID --last-value 0  --fields-terminated-by ','

sqoop job --meta-connect jdbc:hsqldb:hsql://sandbox.hortonworks.com:16000/sqoop --create timetable_newData -- import --connect jdbc:mysql://localhost/CDW_SAPP --driver com.mysql.jdbc.Driver --query "SELECT CONCAT(YEAR, LPAD(MONTH,2,0),LPAD(DAY,2,0) ) AS TIMEID ,
DAY, MONTH, (CASE WHEN MONTH <= 3 THEN 1
      WHEN MONTH > 3 AND MONTH <= 6 THEN 2
      WHEN MONTH > 6 AND MONTH <= 9 THEN 3
      ELSE 4 END ) AS QUARTER, YEAR, TRANSACTION_ID
FROM CDW_SAPP_CREDITCARD WHERE \$CONDITIONS" -m 1 --incremental append --target-dir /user/Credit_Card_System/CDW_SAPP_TIME/ --check-column TRANSACTION_ID --last-value 0 --fields-terminated-by ','


