package com.cdw.constants;

public class ViewData {

	private ViewData() {
			
	}

	public static String BILL_BOT_LINE =
			 "|_______________________________________________________________________________________\n";
	public static String BILL_COL_TITLE =
			"Trans.ID\tYear\tMonth\tDay\tBranch_Code\tTransact.Value\tTransaction type\n";
	public static String BILL_COL_TITLE_UNDER = 
			"________\t____\t______\t___\t__________\t______________\t________________";
	
	public static String LINE_S_WIDTH =
			"************************************************************************************************************************\n";
	public static String LINE_D_WIDTH =
			"_________________________________________________________________________________________________________________________\n";
	public static String LINE_X_WIDTH =
			"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n";
	public static String LINE_LD_WIDTH =
			"-------------------------------------------------------------------------------------------------------------------------\n";
	public static String LINE_DD_WIDTH =
			"#########################################################################################################################\n";
	
	public static String  LINE_TILDE =
	        "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
	public static String LINE_BLANK_WIDTH =
			"                                                                                                                         \n";
}
