package com.cdw.constants;

import java.util.ArrayList;
import java.util.List;

public class SimpleMenu  {
	
	List<String> menu;
	private static int MAX_WIDTH = 120;
	
	public SimpleMenu() {
		ArrayList<String> menuList = new ArrayList<>();
		menuList.add("View Transaction By Zip Code");
		menuList.add("View Totals By Transaction Type");
		menuList.add("View Totals By State");
		menuList.add("View Customer Details By SSN");
		menuList.add("Edit Customer's Information");
		menuList.add("View Monthly bill By Credit Card");
		menuList.add("View a Customer's Transaction Between Two Dates");
		menu = menuList;
	}
	
	public SimpleMenu(List<String> menu) {
		super();
		this.menu = menu;
	}

	/**
	 * @return the menu
	 */
	public final List<String> getMenu() {
		return menu;
	}

	public void DisplayMenu() {
		int i =0;
		for (String m : menu) {
			System.out.printf("%3s)  %s \n", ++i,m);
		}
	}
	
	
	public String linePad(String ch) {
		String sline = "";
		int i = ch.length()-1;
		sline = ch;
		while (i <= MAX_WIDTH) {
			sline += sline + ch;
			i+=ch.length();
		}
		return sline.substring(0, MAX_WIDTH);
		
	}
	
	public String linePad(String ch, int maxSize) {
		String sline = "";
		int i = ch.length()-1;
		sline = ch;
		while (i <= maxSize) {
			sline += sline + " " + ch;
			i+=ch.length();
		}
		return sline.substring(0, maxSize);
		
	}
	
	
 }
