package com.cdw.test;

public class NameNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NameNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public NameNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
