package com.cdw.runner;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cdw.Controller.InOutController;
import com.cdw.blo.CustomerBLO;
import com.cdw.blo.TransactionBLO;
import com.cdw.constants.SimpleMenu;
import com.cdw.constants.ViewData;
import com.cdw.dao.DBProperties;
import com.cdw.exceptions.DBConfigException;
import com.cdw.model.Customer;
import com.cdw.model.Transaction;

/**
 * @author AO
 *
 */
public class MenuCDW {

	public static final String DATE_START_ON = "01/01/1700";
	static Scanner  readData = null;
	public static void main(String[] args) throws DBConfigException{
		      
		boolean stayInMainMenu =true;
		SimpleMenu menu = new SimpleMenu();
		InOutController inOutCtrl = InOutController.getInstance();
		readData = new Scanner(System.in);
		while(stayInMainMenu) {
			try {
				stayInMainMenu = databaseSelection();
			} catch(DBConfigException e) {
				System.out.println(inOutCtrl.textToDisplay(e.getMessage(),e.getExceptionTitle(),4,"@") );
				break;
			}
			stayInMainMenu = creditCardManagMainMenu(menu);
			
		}

	} //public static void main


	/**
	 * @param menu - SimpleMenu class
	 * @return false if the system went throw an exception
	 * @throws NumberFormatException - Exception
	 */
	public static boolean creditCardManagMainMenu(SimpleMenu menu) throws NumberFormatException {
		String line;
		InOutController inOutCtrl = InOutController.getInstance();
		while (true) {
			StringBuilder sb = new StringBuilder();
			sb.append("\nWhat would you like to do?\n\n");
			sb.append(inOutCtrl.listToMenu(menu.getMenu())+ "   \nEnter space to quit the application\n");
			StringBuilder textView = inOutCtrl.textToDisplay(sb.toString(), "  CREDIT CARD MANAGEMENT SYSTEM - MAIN MENU   ");
			System.out.println(textView);
    		line=inputIntegerValue("Enter your selection number: ",1,7); 		
			if(line.trim().equals("")) {
				return false;  // Enter space to quit
			}
			int iSelect = Integer.valueOf(line);
			switch(iSelect) {
				case 1:
					if(!transactionByZipCode()) { continue; }
					break;
				case 2: 
					if(!transactionNumTotByType()) { continue; }
					break;	
				case 3: 
					if(!transactionNumTotByState()) { continue; }
					break;		
			  	case 4:
				   if(!viewCustomerBySSN()) { continue;  }
				   break;
			  	case 5:
				   if(!editCustomerBySSN()) { continue;  }
				   break;   
			  	case 6:
				   if(!CustomerBillsByMonth()) { continue;  }
				    break;  
			  	case 7:
				   if(!CustomerTransactionByPeriode()) { continue;  }
				   break;      
			  } //switch(iSelect)
		} // while (true)
	}







	/**
	 * @param menu -  SimpleMenu
	 * @return false if the system went throw an exception
	 * @throws DBConfigException - RuntimeException
	 * @throws NumberFormatException
	 * In case of multiple databases configuration in the properties files, 
	 * this method will display the database selection menu so the user will be able to 
	 * select the database he would like to connect to.
	 */
	public static boolean databaseSelection() throws DBConfigException, NumberFormatException {
		String line;
		InOutController inOutCtrl = InOutController.getInstance();
		int iSelect =0;
		List<String> myDBList = DBProperties.getInstance().getDatabases();
		if(myDBList.size()> 1) { // More than one database in the properties files
			StringBuilder dblist = new StringBuilder();
			dblist.append("\nChoose the database you would like to connect to?\n\n");
			dblist.append(inOutCtrl.listToMenu(myDBList));
			dblist.append("   \nEnter space to quit the application\n");
			dblist = inOutCtrl.textToDisplay(dblist.toString()," DATABASE SELECTION MENU ");
			System.out.println(dblist);
			line=inputNumericValue("Enter your selection number: ",1,myDBList.size()); 
			if(line.trim().equals("")) return false; // Enter space to quit
			iSelect = Integer.valueOf(line);
	} else if(myDBList.size()== 1) {
		   iSelect = 1;
		}
		DBProperties.getInstance().setCurrentDatabaseName(myDBList.get(iSelect-1)); 
		return true;
	}





	
	
	private static boolean CustomerTransactionByPeriode() {

		InOutController inOutCtrl = InOutController.getInstance();
		ArrayList<Transaction> transactions;
		
		System.out.println(inOutCtrl.textToDisplay("\nYou will need to provide: SSN#, Start Date, End Date \n \n"," CUSTOMER'S TRANSACTIONS BETWEEN TWO DATES "));
		String  ssn;
	    Date startDate, endDate;
	    ssn=inputNumericValue("Enter space to return to the main menu.\nEnter SSN#: ");
		if (iSBlank(ssn)) { return false;}
	    while(true)  {
	        startDate=inputDateValue("Enter space to return to the main menu.\nEnter Start Date(mm/dd/yyyy) : ");
	        if (startDate==null) {return false;}
	       
	        endDate=inputDateValue("Enter space to return to the main menu.\nEnter End Date(mm/dd/yyyy) : ");
	        if (endDate==null) {return false;}
		    if(endDate.before(startDate)) {
		    	System.out.println("Incorrect periode!");
		    	System.out.println("Start date should be before the End date.");
		    	continue;
		    }
		    
		    break;
	    }
	  try {
		    TransactionBLO transactionBL = TransactionBLO.getInstance();
		       
		    transactions = transactionBL.getCustomerTransactionByPeriode(ssn, startDate, endDate);
			   if (transactions==null) return false;
			   if(transactions.size()==1) {
				   System.out.println(transactions.get(0).toString());
			   } else {
				   CustomerBLO customerBLO = CustomerBLO.getInstance();
				   Customer customer = customerBLO.getCustomerBySSN(transactions.get(0).getCust_SSN()).get(0);
				   int trSize = transactions.size();
				   customer.setTransactionCount(transactions.get(trSize-1).getTransactionCount());
				   customer.setTransactionTotal(transactions.get(trSize-1).getTransactionTotal());
				   StringBuilder sb = new StringBuilder();
				   sb.append(" \n"+customer.customerToBills());
				   sb.append(String.format("%-21s:  %s to %s\n","Transaction period",startDate ,endDate));
				   sb.append(ViewData.LINE_S_WIDTH.substring(3));
				   String title= String.format("%-10S  %-10S  %11S  %18S  %-25S\n",
							"Trans.ID", "Date", "Branch_Code", "Transaction Value",  "Transaction Type") ;
				   sb.append(title);
				   sb.append(ViewData.LINE_S_WIDTH.substring(3));
				   int i=0;
					for(i=0;i<transactions.size()-1;i++) {
						sb.append(transactions.get(i).getBillingList());
					}   
					Transaction tr=transactions.get(i);
					sb.append(ViewData.LINE_S_WIDTH.substring(3));
					sb.append(String.format("%-35s  %18.3f\n","TRANSACTIONS TOTAL",tr.getTransactionTotal()));
					sb = inOutCtrl.textToDisplay(sb.toString()," CUSTOMER'S TRANSACTIONS INFORMATION - SSN# " + ssn + " ");
					System.out.println(sb);
			   }
		  
	  }  catch(DBConfigException e) {
	    	System.out.println(inOutCtrl.textToDisplay(e.getMessage(),e.getExceptionTitle(),4,"@") );
	    	inputNumericValue("Please press enter to continue ");
			return false;
	   }
	
		  System.out.println();  
		  inputNumericValue("Please press enter to continue ");
	    
		return true;
	}


	/**
	 * @Description : Ask the user to enter a Date value
	 * @Input (msg) : Message to display on the screen
	 * Only date value will be accepted
	 * Enter a white space to leave
	 */
	private static Date inputDateValue(String msg) {
		String line="" ;
		Date d=null, exceptday;
		
		while (true) {
			System.out.println(msg);
			line=readData.nextLine();
			if(line.trim().equals("")) break; // Enter space to leave
			if(!line.contains("/") && line.contains("-")) {
			    	line=line.replace("-", "/");
		    }
			d = InOutController.getInstance().getDateValue(line, "MM/dd/yyyy");
			if(d== null) {continue;}
			exceptday =InOutController.getInstance().getDateValue(DATE_START_ON, "MM/dd/yyyy");
			if (d.before(exceptday)) {
				System.out.println("Invalid date!");
		    	System.out.println("The enter date can not be before " + DATE_START_ON);
		    	continue;
			}
			line=DateTimeFormatter.ofPattern("MM/dd/yyyy").format(LocalDate.now());
			exceptday = InOutController.getInstance().getDateValue(line, "MM/dd/yyyy");
			if (d.after(exceptday)) {
				System.out.println("Invalid date!");
		    	System.out.println("The enter date can not be after today!.");
		    	continue;
			}
			break;
		} //while (true)
		return d;
	}


	
	private static boolean CustomerBillsByMonth() {
		
		InOutController inOutCtrl = InOutController.getInstance();
		ArrayList<Transaction> transactions;
		
		System.out.println(inOutCtrl.textToDisplay("\nYou will need to provide: Credit card#, Year, Month \n \n"," MONTHLY BILLING BY CREDITCARD# "));
		String line="", creditCard;
		   int month=0, year=0;
		   System.out.println("Enter space to return to the main menu.");
		   creditCard=inputNumericValue("Enter Credit Card No: ");
		   if (iSBlank(creditCard)) { return false;}
		   line=inputYearMonthOrDayValue("Enter the Year: ",1);
		   if (iSBlank(line)) return false;
		   year = Integer.valueOf(line);
		   line=inputYearMonthOrDayValue("Enter the Month: ",2);
		   if (iSBlank(line)) return false;
		   month = Integer.valueOf(line);
		   try {
			   TransactionBLO transactionBLO = TransactionBLO.getInstance();
			   transactions = transactionBLO.getCustomerBillsByMonth(creditCard, year, month);
			   if(transactions.size()==1) {
				   System.out.println(transactions.get(0).toString());
			   } else {
				   CustomerBLO customerBLO = CustomerBLO.getInstance();
				   Customer customer = customerBLO.getCustomerBySSN(transactions.get(0).getCust_SSN()).get(0);
				   int trSize = transactions.size();
				   customer.setTransactionCount(transactions.get(trSize-1).getTransactionCount());
				   customer.setTransactionTotal(transactions.get(trSize-1).getTransactionTotal());
				   StringBuilder sb = new StringBuilder();
				   sb.append(" \n"+customer.customerToBills());
				   sb.append(String.format("%-21s:  %02d/%d\n","Billing period ",month ,year));
				   sb.append(ViewData.LINE_S_WIDTH.substring(3));
				   String title= String.format("%-10S  %-10S  %11S  %18S  %-25S\n",
							"Trans.ID", "Date", "Branch_Code", "Transaction Value",  "Transaction Type") ;
				   sb.append(title);
				   sb.append(ViewData.LINE_S_WIDTH.substring(3));
				   int i=0;
					for(i=0;i<transactions.size()-1;i++) {
						sb.append(transactions.get(i).getBillingList());
					}   
					Transaction tr=transactions.get(i);
					sb.append(ViewData.LINE_S_WIDTH.substring(3));
					sb.append(String.format("%-35s  %18.3f\n","TRANSACTIONS TOTAL",tr.getTransactionTotal()));
					sb = inOutCtrl.textToDisplay(sb.toString()," CUSTOMER BILLING INFORMATION - CREDITCARD# " + creditCard + " ");
					System.out.println(sb);
			   }
			   
		   }  catch(DBConfigException e) {
		    	System.out.println(inOutCtrl.textToDisplay(e.getMessage(),e.getExceptionTitle(),4,"@") );
		    	inputNumericValue("Please press enter to continue ");
				return false;
		   }
		 
		  System.out.println();  
		  line=inputNumericValue("Please press enter to continue ");
		
		return false;
	}


	/**
	 * To display the number and total values of transactions 
	 * for branches in a given state
	 * @ScreenOutput: 
	 * User will enter : The branches State
	 *  
	 */
	private static boolean transactionNumTotByState() {
		InOutController inOutCtrl = InOutController.getInstance();
		
		System.out.println(inOutCtrl.textToDisplay("\nYou will need to provide: State code \n \n"," TOTAL TRANSACTIONS BY BRANCH CODE FOR A GIVING STATE "));
		System.out.println("Enter space to return to the main menu.");
		 System.out.println("Enter the State: ");
		 String transState=readData.nextLine();
		 if (iSBlank(transState)) { return false;}
		 try {
			 TransactionBLO transactionBL = TransactionBLO.getInstance();
			 StringBuilder transactionInfo = transactionBL.getTransactionNumTotByState(transState);
			 transactionInfo = inOutCtrl.textToDisplay(" \n"+transactionInfo.toString()+" \n"," STATISTIC TRANSACTION BY BRANCH FOR STATE: " + transState.toUpperCase() + " ");
			 System.out.println(transactionInfo);
			 inputNumericValue("Please press enter to continue ");
				 
		 }  catch(DBConfigException e) {
		    	System.out.println(inOutCtrl.textToDisplay(e.getMessage(),e.getExceptionTitle(),4,"@") );
		    	inputNumericValue("Please press enter to continue ");
				return false;
		   }
		 return true;
	}

			
	

	/**
	 * To display the number and total values of transactions for a given type.
	 * @ScreenOutput: 
	 * User will enter : The transaction type
	 *  
	 */
	private static boolean transactionNumTotByType() {
		InOutController inOutCtrl = InOutController.getInstance();
		
		System.out.println(inOutCtrl.textToDisplay("\nYou will need to provide: Transaction Type \n \n"," TOTAL TRANSACTIONS BY TRANSACTION TYPE "));
		System.out.println("Enter space to return to the main menu.");
		 System.out.println("Enter transaction type: ");
		 String transType=readData.nextLine();
		 if (iSBlank(transType)) { return false;}
		 try {
			 TransactionBLO transactionBL = TransactionBLO.getInstance();
			 StringBuilder transactionInfo = transactionBL.getTransactionNumTotByType(transType);
			 transactionInfo = inOutCtrl.textToDisplay(" \n"+transactionInfo.toString()+" \n"," STATISTIC TRANSACTION FOR TRANSACTION TYPE: " + transType + " ");
			 System.out.println(transactionInfo);
			 inputNumericValue("Please press enter to continue ");
			 
		 }  catch(DBConfigException e) {
		    	System.out.println(inOutCtrl.textToDisplay(e.getMessage(),e.getExceptionTitle(),4,"@") );
		    	inputNumericValue("Please press enter to continue ");
				return false;
		   }
		 return true;
	}
	
	
	/**
	 * To display the transactions made by customers living in a given zip code for a
	 * given month and year. Order by day in descending order
	 * Display the list of transaction for the giving zip code, year, and month.
	 * User will enter :
	 * @param - Customer ZipCode
	 * @param - Year and month of transaction
	 *  
	 * @return False if any exception
	 */
	private static boolean transactionByZipCode() {
		ArrayList<Transaction> transactions;
		InOutController inOutCtrl = InOutController.getInstance();
		
		System.out.println(inOutCtrl.textToDisplay("\nYou will need to provide: Zipcode#, Year, Month \n \n"," TRANSACTIONS LIST BY ZIP CODE "));
		String line="", zipcode;
		   int month=0, year=0;
		   System.out.println("Enter space to return to the main menu.");
		   zipcode=inputNumericValue("Enter customer zip code: ");
		   if (iSBlank(zipcode)) { return false;}
		   line=inputYearMonthOrDayValue("Enter the Year: ",1);
		   if (iSBlank(line)) return false;
		   year = Integer.valueOf(line);
		   line=inputYearMonthOrDayValue("Enter the Month: ",2);
		   if (iSBlank(line)) return false;
		   month = Integer.valueOf(line);
		   try {
			   TransactionBLO transactionBL = TransactionBLO.getInstance();
			   transactions = transactionBL.getTransactionByZipCode(zipcode, year, month);
			   if(transactions.size()==1) {
				   System.out.println(transactions.get(0).toString());
			   } else {
				   viewTransactionByZipCode(transactions,zipcode, String.format("%02d/%d",month, year));   
			   }   
		   } catch(DBConfigException e) {
		    	System.out.println(inOutCtrl.textToDisplay(e.getMessage(),e.getExceptionTitle(),4,"@") );
		    	inputNumericValue("Please press enter to continue ");
				return false;
		    }
		   
		 	line=inputNumericValue("Please press enter to continue ");
			return true;
	}


	/**
	 * Display the list of transaction for a giving Zip code and period. 
	 * @param transactions - List of transaction records
	 * @param periode - month/Year '02/2018'
	 * @param zipcode - Zip code
	 */
	public static void viewTransactionByZipCode(ArrayList<Transaction> transactions,
			String zipcode, String periode) {

		InOutController inOutCtrl = InOutController.getInstance();
		
		StringBuilder sbTransList = new StringBuilder();
		String title = "Transaction information \n";
			sbTransList.append(title);
			sbTransList.append(String.format("%-25s: %-10s\n","Periode", periode));		 
			sbTransList.append(String.format("%-25s: %-10s\n","Zip code", zipcode));
			sbTransList.append(ViewData.LINE_S_WIDTH.substring(3));
			sbTransList.append(String.format("%10s  %-10s  %17s  %10s  %11s  %18s  %-25s\n",
				   "TRANS.ID","DATE","CREDIT CARD #","CUST.SSN#","BRANCH CODE", 
				           "TRANSACTION VALUE","TRANSACTION TYPE"));
			sbTransList.append(ViewData.LINE_S_WIDTH.substring(3));
			Transaction tr;
			int i=0;
			for(i=0;i<transactions.size()-1;i++) {
				tr=transactions.get(i);
				sbTransList.append(tr.toListString());
			}
			tr=transactions.get(i);
			sbTransList.append(ViewData.LINE_S_WIDTH.substring(3));
			sbTransList.append(String.format("%68s%18.3f\n",tr.getTransactionType(),tr.getTransactionTotal()));
			sbTransList = inOutCtrl.textToDisplay(sbTransList.toString()," TRANSACTION LIST FOR ZIP CODE: " + zipcode + " ");
			System.out.println(sbTransList);
	}

	// Return true if the giving string is empty
	private static boolean iSBlank(String line) {
		boolean blankString = false;
		if(line.trim().equals("")) 
		    { // Enter space to return to the main menu
		    	return true;
		    }
		return blankString;
	}

	
	/**
	 * @param menu 
	 * @ScreenOutput: Display the customer info for the giving SSN
	 * @UserInput   : SSN
	 * Display the customer information on the screen
	 */
	private static boolean viewCustomerBySSN() {
		boolean returnValue =false;
		List<Customer> customers;
		InOutController inOutCtrl = InOutController.getInstance();
		String line;
		int ssn;
	   
		System.out.println(inOutCtrl.textToDisplay("\nYou will need to provide: SSN# \n \n","  VIEW CUSTOMER'S INFORMATION BY SSN# "));
		System.out.println("Enter space to return to the main menu.");
	   	line=inputIntegerValue("Please enter customer SSN: ");
	    if (iSBlank(line)) {return false; };
	    ssn = Integer.valueOf(line);
	    CustomerBLO customerBLO = CustomerBLO.getInstance();
	    try {
	    	customers = customerBLO.getCustomerBySSN(ssn);
	    	Customer cust ;
	    	if(customers != null) {
	    		if (customers.size() == 1) {
	    			cust = customers.get(0);
					returnValue = viewCustomerInformation(cust, ssn);
				} else {
					int i;
					int iSelect = creditCardSelectMenu(customers, ssn);
					if(iSelect==-1) {return false;}
					if(iSelect <= customers.size()) {
						cust = customers.get(iSelect-1);
						returnValue = viewCustomerInformation(cust, ssn);	
					} else {
						for(i=0;i<customers.size();i++) {
							cust = customers.get(i);
							returnValue = viewCustomerInformation(cust, ssn);
						}
					}
					
				}
			} else {
				System.out.println("No customer found with the SSN: " + ssn );
				inputNumericValue("Please press enter to continue ");
				returnValue = false;
			}
			inputNumericValue("Please press enter to continue ");
			
	    } catch(DBConfigException e) {
	    	System.out.println(inOutCtrl.textToDisplay(e.getMessage(),e.getExceptionTitle(),4,"@") );
	    	inputNumericValue("Please press enter to continue ");
			return false;
	    }
		return returnValue;
    }







	/**
	 * @param customers - List of customers
	 * @param ssn - Social Security Number
	 * @return int Selection value 
	 * 
	 */
	public static int creditCardSelectMenu(List<Customer> customers, int ssn)
			throws NumberFormatException {
		String line;
		InOutController inOutCtrl = InOutController.getInstance();
		StringBuilder custList = new StringBuilder();
		Customer cust;
		int i=0;
		custList.append("\nWhat credit card would like to view?\n");
		for(i=0;i<customers.size();i++) {
			cust = customers.get(i);
			custList.append(String.format("%3s)  %s \n",i+1, cust.getCreditCardNo()));
		}
		custList.append(String.format("%3s)  %s \n",i+1, "All credit cards"));
		custList.append("\nEnter space to return to the Main menu. \n");
		custList = inOutCtrl.textToDisplay(custList.toString(),
				" CHOOSE CREDIT CARD TO VIEW - SSN: " + ssn + " ");
		System.out.println(custList);	
		line=inputNumericValue("Enter your selection number: ",1,customers.size()+1); 
		if(line.trim().equals("")) return -1; // Enter space to quit
		int iSelect = Integer.valueOf(line);
		return iSelect;
	}

	/**
	 * @param customer - Customer record
	 * @param ssn -  Social Security Number
	 * @return false if the system went throw an exception 
	 * Display on the screen the customer at the index ix in the list of customers
	 */
	public static boolean viewCustomerInformation(Customer customer,	int ssn) {
		boolean returnValue;
		InOutController inOutCtrl = InOutController.getInstance();
		
		StringBuilder custList = new StringBuilder();
		custList.append(customer.toViewString());
		custList.append("   \nPlease press enter to continue\n");
		custList = inOutCtrl.textToDisplay(custList.toString()," CUSTOMER INFORMATION - SSN: " + ssn + " ");
		System.out.println(custList);
		returnValue = true;
		return returnValue;
	}

	/**
	 * To modify the existing account details of a customer 
	 * @ScreenOutput: Display the customer info for the giving SSN
	 * 
	 * @UserInput   : SSN, 
	 *     			  Select the field to change, change the selected field
	 *     			  repeat the select action until the end of change
	 *     			  Select action 0 to commit your change	
	 */
	private static boolean editCustomerBySSN() {
		InOutController inOutCtrl = InOutController.getInstance();
		boolean returnValue;
		Customer customer=null;
		List<Customer> customers;
		InOutController menu = InOutController.getInstance();
		String line;
		int ssn;
		System.out.println(inOutCtrl.textToDisplay("\nYou will need to provide: SSN# \n \n"," EDIT CUSTOMER BY SSN# "));
		System.out.println("Enter space to return to the main menu.");
	    line=inputNumericValue("Please enter customer SSN: ");
	    if (iSBlank(line)) { return false;}
	    ssn = Integer.valueOf(line);
	    CustomerBLO customerBLO = CustomerBLO.getInstance();
	    try {
			customers = customerBLO.getCustomerBySSN(ssn);
			if(customers != null) {
	    		if (customers.size() == 1) {
	    			customer = customers.get(0);
	    			returnValue = updateSelectedCustomer(customer, ssn, customerBLO);
				} else {
					int iSelect = creditCardSelectMenu(customers, ssn);
					if(iSelect==-1) {return false;}
					customer = customers.get(iSelect-1);
	    			returnValue = updateSelectedCustomer(customer, ssn, customerBLO);
				}
			}else {
					System.out.println("No customer found with the SSN: " + ssn );
					inputNumericValue("Please press enter to continue ");
					returnValue = false;
			}
	    } catch (DBConfigException e) {
	    	System.out.println(menu.textToDisplay(e.getMessage(),e.getExceptionTitle(),4,"@") );
	    	inputNumericValue("Please press enter to continue ");
			return false;
		}
		return returnValue;
    }







	/**
	 * @param customer -  Customer info
	 * @param ssn - Social Security Number
	 * @param customerBLO - Business Logic Object
	 * @return false if the system went throw an exception 
	 */
	public static boolean updateSelectedCustomer(Customer customer, int ssn, CustomerBLO customerBLO) {
		boolean returnValue;
		Customer cust;
		if(customer != null) {
			cust =updateCustomer(customer);
			if( cust != null) {
				customer = cust;
				customerBLO.saveCustomer(customer);
				returnValue = viewCustomerInformation(customer, ssn);
				System.out.println("Customer information has been updated.");
				inputNumericValue("Please press enter to continue ");
			}
			returnValue = true;
		} else {
			System.out.println("No customer found with the SSN: " + ssn );
			returnValue = false;
		}
		return returnValue;
	}

	
	private static Customer updateCustomer(Customer customer) {
		boolean noChange = true;
		String line = "x";
		Customer cust = new Customer(customer);
		InOutController inOutCtrl = InOutController.getInstance();
		
		while (!iSBlank(line) && !line.equals("0")) {
			StringBuilder custList = new StringBuilder();
			custList.append(cust.SelectFieldToEdit());
			custList.append("14) Edit all fields\n\n");
			custList.append("Enter 0 to commit all your modification!\n");
			custList.append("Enter white space to cancel the change or to return to the main menu!\n");
			custList.append("Please, select the field you woould like to change or 14 to to change all fields!\n  \n");
			custList = inOutCtrl.textToDisplay(custList.toString()," MAJ CUSTOMER INFORMATION - SSN: " + customer.getSsn() + " ");
			System.out.println(custList);
			
//			System.out.println(cust.SelectFieldToEdit());
//			System.out.println("14) Edit all fields");
//			System.out.println("Enter 0 to commit all your modification!");
//			System.out.println("Enter white space to cancel the change or to return to the main menu!");
			line = inputNumericValue("Please, select the field you woould like to change or 14 to to change all fields! ",0,14);
			if (iSBlank(line)) { break;}
			if(noChange && Integer.valueOf(line) == 0) { // Commit the change if any.
			  System.out.println("You did not made any change on this current customer.");
			  inputNumericValue("Please press enter to continue ");
			  continue;
			}
			switch(Integer.valueOf(line)) {
				case 1:
					line = inputValue("Enter First Name: ");
					if (!iSBlank(line))	cust.setfName(line);
					noChange = false;
					break;
				case 2:
					line = inputValue("Enter Middle Name: ");
					if (!iSBlank(line)) cust.setmName(line);
					noChange = false;
					break;
				case 3:
					line = inputValue("Enter Last Name: ");					
					if (!iSBlank(line)) cust.setlName(line);
					noChange = false;
					break;	
				case 4:
					System.out.println("SSN can not be modified. ");
					/*line = inputNumericValue("Enter SSN: ");
					if (!iSBlank(line)) cust.setSsn(Integer.valueOf(line));*/
					break;	
				case 5:
					System.out.println("Credit Card# can not be modified. ");
//					line = inputNumericValue("Enter creditCardNo: ");
//					if (!iSBlank(line)) cust.setCreditCardNo(line);
//					noChange = false;
					break;
				case 6:
					line = inputValue("Enter State: ");
					if (!iSBlank(line)) cust.setState(line);
					noChange = false;
					break;	
				case 7:
					line = inputValue("Enter StreetName: ");
					if (!iSBlank(line)) cust.setStreetName(line);
					noChange = false;
					break;
				case 8:
					line = inputValue("Enter Country: ");
					if (!iSBlank(line)) cust.setCountry(line);
					noChange = false;
					break;
				case 9:
					line = inputValue("Enter City: ");
					if (!iSBlank(line)) cust.setCity(line);
					noChange = false;
					break;
				case 10:
					line = inputValue("Enter Email: ");
					if (!iSBlank(line)) cust.setEmail(line);
					noChange = false;
					break;
				case 11:
					line = inputValue("Enter Zip: ");
					if (!iSBlank(line)) cust.setZip(line);
					noChange = false;
					break;
				case 12:
					line = inputValue("Enter AptN: ");
					if (!iSBlank(line)) cust.setAptN(line);
					noChange = false;
					break;
				case 13:
					line = inputNumericValue("Enter Phone: ");
					if (!iSBlank(line)) cust.setPhone(Integer.valueOf(line));
					noChange = false;
					break;	
				case 14: 
					line = inputValue("Enter First Name: ");
					if(line.equals("0")) { break;}
					if (!iSBlank(line))	cust.setfName(line);
					noChange = false;
					line = inputValue("Enter Middle Name: ");
					if(line.equals("0")) {break;}
					if (!iSBlank(line)) cust.setmName(line);
					noChange = false;
					line = inputValue("Enter Last Name: ");					
					if(line.equals("0")) {break;}
					if (!iSBlank(line)) cust.setlName(line);
					noChange = false;
//					line = inputNumericValue("Enter creditCardNo: ");
//					if(line.equals("0")) {break;}
//					if (!iSBlank(line)) cust.setCreditCardNo(line);
//					noChange = false;
					line = inputValue("Enter State: ");
					if(line.equals("0")) {break;}
					if (!iSBlank(line)) cust.setState(line);
					noChange = false;
					line = inputValue("Enter StreetName: ");
					if(line.equals("0")) {break;}
					if (!iSBlank(line)) cust.setStreetName(line);
					noChange = false;
					line = inputValue("Enter Country: ");
					if(line.equals("0")) {break;}
					if (!iSBlank(line)) cust.setCountry(line);
					noChange = false;
					line = inputValue("Enter City: ");
					if(line.equals("0")) {break;}
					if (!iSBlank(line)) cust.setCity(line);
					noChange = false;
					line = inputValue("Enter Email: ");
					if(line.equals("0")) {break;}
					if (!iSBlank(line)) cust.setEmail(line);
					noChange = false;
					line = inputNumericValue("Enter Zip: ");
					if(line.equals("0")) {break;}
					if (!iSBlank(line)) cust.setZip(line);
					noChange = false;
					line = inputValue("Enter AptN: ");
					if(line.equals("0")) {break;}
					if (!iSBlank(line)) cust.setAptN(line);
					noChange = false;
					line = inputNumericValue("Enter Phone: ");
					if(line.equals("0")) {break;}
					if (!iSBlank(line)) cust.setPhone(Integer.valueOf(line));
					noChange = false;
					break;
			} //switch(Integer.valueOf(line)) {
			if(line.equals("0") && !noChange) {
				return cust;
			}
		}
		return null;
	}


	/**
	 * @Description : Ask the user to enter a numeric value
	 * @Input (msg) : Message to display on the screen
	 * Only numeric value will be accepted
	 * Enter a white space to leave
	 */
	private static String inputNumericValue(String msg) {
		String line="";
		while (true) {
			System.out.println(msg);
			try {
				line=readData.nextLine();
				if(line.trim().equals("")) break; // Enter space to leave
				Double.valueOf(line);
			} catch (NumberFormatException e) {
				System.out.println("Invalid numeric value: " + e.getMessage());
				continue;
			}
			break;
		}
		return line;
	 }
	
	/**
	 * @Description : Ask the user to enter a numeric value
	 * @Input (msg) : Message to display on the screen
	 * Only numeric value will be accepted
	 * Enter a white space to leave
	 */
	private static String inputIntegerValue(String msg) {
		String line="";
		while (true) {
			System.out.println(msg);
			try {
				line=readData.nextLine();
				if(line.trim().equals("")) break; // Enter space to leave
				Integer.valueOf(line);
			} catch (NumberFormatException e) {
				System.out.println("Invalid numeric value: " + e.getMessage());
				continue;
			}
			break;
		}
		return line;
	 }
	
	private static String inputValue(String msg) {
		String line="";
			System.out.println(msg);
			line=readData.nextLine();
		
		    return line;
	 }

	/**
	 * @Description : Ask the user to enter a numeric value
	 * @Input (msg) : Message to display on the screen
	 * 			low : The lowest value the numeric variable can take
	 * 			high: The highest value the numeric variable can take	
	 * Only numeric value will be accepted
	 * Enter a white space to leave
	 */
	private static String inputNumericValue(String msg, double low, double high) {
		String line="";
		double d;
		
		if (low > high) {
			System.out.println("Inconsistent parameters. \nYour lower value (" + low + ") is higher than your higher value (" + high + ")");
			readData.nextLine();
			return line;
		} 
		while (true) {
			System.out.println(msg);
			try {
				line=readData.nextLine();
				if(line.trim().equals("")) break; // Enter space to leave
				d = Double.valueOf(line);
				if(d < low || d> high) {
				   System.out.println("Invalid value " + line);	
				   System.out.println("Plaese, enter a value between " + Math.round(low) + " and " + Math.round(high));
				   continue;
				}
			} catch (NumberFormatException e) {
				System.out.println("Invalid numeric value: " + e.getMessage());
				continue;
			}
			break;
		}
		return line;
	 }
	
	/**
	 * @Description : Ask the user to enter a numeric value
	 * @Input (msg) : Message to display on the screen
	 * 			low : The lowest value the numeric variable can take
	 * 			high: The highest value the numeric variable can take	
	 * Only numeric value will be accepted
	 * Enter a white space to leave
	 */
	private static String inputIntegerValue(String msg, int low, int high) {
		String line="";
		int d;
		
		if (low > high) {
			System.out.println("Inconsistent parameters. \nYour lower value (" + low + ") is higher than your higher value (" + high + ")");
			readData.nextLine();
			return line;
		} 
		while (true) {
			System.out.println(msg);
			try {
				line=readData.nextLine();
				if(line.trim().equals("")) break; // Enter space to leave
				d = Integer.valueOf(line);
				if(d < low || d> high) {
				   System.out.println("Invalid value " + line);	
				   System.out.println("Plaese, enter a value between " + Math.round(low) + " and " + Math.round(high));
				   continue;
				}
			} catch (NumberFormatException e) {
				System.out.println("Invalid numeric value: " + e.getMessage());
				continue;
			}
			break;
		}
		return line;
	 }
	
	/**
	 * @Description : Ask the user to enter an integer value for year or month or day
	 * @Input (msg) : Message to display on the screen
	 * @Input (iValue): 0 for any year greater than 1900
	 * 					1 for any year between 1900 and the current year
	 * 					2 for the month between 1 and 12
	 * 					3 for the day between 1 and 31
	 * Only numeric value will be accepted
	 * Enter a white space to leave
	 */
	private static String inputYearMonthOrDayValue(String msg, int iValue) {
		String line="";
		
		while (true) {
			System.out.println(msg);
			try {
				line=readData.nextLine();
				if(line.trim().equals("")) break; // Enter space to leave
				Double.valueOf(line);
				if(iValue == 0) {
					if (Double.valueOf(line) < 1900 ) {
						System.out.println("Invalid year value: " + line);
						System.out.println("Year has to be greater than 1900");
						continue;
					}
				} else if(iValue == 1) {
					int currentYear = Calendar.getInstance().get(Calendar.YEAR);
					if (Double.valueOf(line) < 1900 ) {
						System.out.println("Invalid year value: " + line);
						System.out.println("Year has to be greater than 1900");
						continue;
					} else if (Double.valueOf(line) > currentYear ) {
						System.out.println("Invalid year value: " + line);
						System.out.println("Year can not to be greater than " + currentYear);
						continue;
					}
				} else if(iValue == 2) {
					if (Double.valueOf(line) < 1 || Double.valueOf(line) > 12 ) {
						System.out.println("Invalid month value: " + line);
						System.out.println("Month has to between 1 and 12 includes");
						continue;
					}
				} else if(iValue == 3) {
					if (Double.valueOf(line) < 1 || Double.valueOf(line) > 31 ) {
						System.out.println("Invalid day value: " + line);
						System.out.println("Day has to between 1 and 31 includes");
						continue;
					}
				}	
			} catch (NumberFormatException e) {
				System.out.println("Invalid numeric value: " + e.getMessage());
				continue;
			}
			break;
		}
		return line;
	}

}
