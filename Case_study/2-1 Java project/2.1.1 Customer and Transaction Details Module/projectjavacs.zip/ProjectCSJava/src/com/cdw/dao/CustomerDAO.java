package com.cdw.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cdw.constants.Queries;
import com.cdw.exceptions.DBConfigException;
import com.cdw.model.Customer;

/**
 * <pre>
 * @author AO
 * Extends ConnectionDAO 
 * Manage the data access layer to the customer informations.
 * All customer direct related business logic request will go 
 * throughout this object to the database.
 * </pre>
 */
public class CustomerDAO extends ConnectionDAO{

	
	/**
	 * @param ssn: Social Security Number 
	 * This method establish connection to the current database and get the customer
	 * informations using the ssn has a parameter. 
	 * As a CDW_SAPP_CUSTOMER table primary is both (ssn, credit_card), the return query
	 * could be one or multiple records.
	 * This method will return a list of customer data.
	 * @return List of customers
	 */
	public List<Customer> getCustomerBySSN(int ssn)  throws DBConfigException  {
		Customer customer = null;
		
		establishConnection();
		String query = Queries.GET_CUSTOMER_BY_SSN;
		ArrayList<Customer> customers = null;
		try {
			state = conn.prepareStatement(query);
			state.setInt(1, ssn);
			result = state.executeQuery();
			while(result.next()) {
				if (customers == null) {
					customers = new ArrayList<Customer>();
				}
				customer=setQueryResult();
				customers.add(customer);
			}
			state.close();
			if (customers == null) {
				throw new DBConfigException(
		                "No customer found with the SSN " + ssn,
		                "INVALID SSN NUMBER");
			}
		} catch (SQLException e) {
			throw new DBConfigException(
	                e.getMessage() +"\n"+ e.toString(), e,
	                "Database request error");
		}
		return customers;
		
	}

	/**
	 *Get customer data from the resultSet object.
	 *Customer data is retrieved using customer query column name 
	 */
	private Customer setQueryResult() throws SQLException {
		Customer customer =new Customer();
		
		customer.setAptN(result.getString("APT_NO"));
		customer.setCity(result.getString("CUST_CITY"));
		customer.setCountry(result.getString("CUST_COUNTRY"));
		customer.setCreditCardNo(result.getString("CREDIT_CARD_NO"));
		customer.setEmail(result.getString("CUST_EMAIL"));
		customer.setfName(result.getString("FIRST_NAME"));
		customer.setlName(result.getString("LAST_NAME"));
		customer.setmName(result.getString("MIDDLE_NAME"));
		customer.setPhone(result.getInt("CUST_PHONE"));
		customer.setSsn(result.getInt("SSN"));
		customer.setState(result.getString("CUST_STATE"));
		customer.setStreetName(result.getString("STREET_NAME"));
		customer.setZip(result.getString("CUST_ZIP"));
		
		
		return customer;
	}

	public void saveCustomer(Customer customer)  throws DBConfigException  {
		// TODO Auto-generated method stub
		
		establishConnection();
		String query = Queries.SET_CUSTOMER_BY_SSN;
		try {
			state = conn.prepareStatement(query);
			
			//state.setString(1, customer.getCreditCardNo());
			state.setString(1, customer.getState());
			state.setString(2, customer.getStreetName());
			state.setString(3, customer.getCountry());
			state.setString(4, customer.getCity());
			state.setString(5, customer.getfName());
			state.setString(6, customer.getmName());
			state.setString(7, customer.getlName());
			state.setString(8, customer.getEmail());
			state.setString(9, customer.getAptN());
			state.setInt(10, customer.getPhone());
			state.setString(11, customer.getZip());
			state.setInt(12, customer.getSsn());
			
			int rs = state.executeUpdate();
			System.out.println(rs);
			state.close();
			
		}	catch (SQLException e) {
			throw new DBConfigException(
	                e.getMessage() +"\n"+ e.toString(), e,
	                "Database update error");
		}
	}
}
