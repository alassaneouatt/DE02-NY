package com.cdw.test;


public class ListTooLargeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ListTooLargeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ListTooLargeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
