package com.cdw.model;

import com.cdw.dao.AbstractDAO;

public class Transaction extends AbstractDAO {

	private int transactionID;  //size = 9
	private int day;			//size = 2
	private int month;			//size = 2
	private int year;			//size = 4
	private String credit_card_no; //size = 16
	private int  cust_SSN;  	//size = 9
	private int branch_code;	//size = 9	
	private String transactionType; //size = 30
	private double transactionValue; //size = 22
	private double transactionTotal;
	private long transactionCount;
	private String title ="";




	/**
	 * @return the transactionID
	 */
	public final int getTransactionID() {
		return transactionID;
	}

	/**
	 * @param transactionID the transactionID to set
	 */
	public final void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}

	/**
	 * @return the day
	 */
	public final int getDay() {
		return day;
	}

	/**
	 * @param day the day to set
	 */
	public final void setDay(int day) {
		this.day = day;
	}

	/**
	 * @return the month
	 */
	public final int getMonth() {
		return month;
	}

	/**
	 * @param month the month to set
	 */
	public final void setMonth(int month) {
		this.month = month;
	}

	/**
	 * @return the year
	 */
	public final int getYear() {
		return year;
	}

	/**
	 * @param year the year to set
	 */
	public final void setYear(int year) {
		this.year = year;
	}

	/**
	 * @return the credit_card_no
	 */
	public final String getCredit_card_no() {
		return credit_card_no;
	}

	/**
	 * @param credit_card_no the credit_card_no to set
	 */
	public final void setCredit_card_no(String credit_card_no) {
		this.credit_card_no = credit_card_no;
	}

	/**
	 * @return the cust_SSN
	 */
	public final int getCust_SSN() {
		return cust_SSN;
	}

	/**
	 * @param cust_SSN the cust_SSN to set
	 */
	public final void setCust_SSN(int cust_SSN) {
		this.cust_SSN = cust_SSN;
	}

	/**
	 * @return the branch_code
	 */
	public final int getBranch_code() {
		return branch_code;
	}

	/**
	 * @param branch_code the branch_code to set
	 */
	public final void setBranch_code(int branch_code) {
		this.branch_code = branch_code;
	}

	/**
	 * @return the transactionType
	 */
	public final String getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType the transactionType to set
	 */
	public final void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the transactionValue
	 */
	public final double getTransactionValue() {
		return transactionValue;
	}

	/**
	 * @param transactionValue the transactionValue to set
	 */
	public final void setTransactionValue(double transactionValue) {
		this.transactionValue = transactionValue;
	}

	/**
	 * @return the transactionTotal
	 */
	public final double getTransactionTotal() {
		return transactionTotal;
	}

	/**
	 * @param transactionTotal the transactionTotal to set
	 */
	public final void setTransactionTotal(double transactionTotal) {
		this.transactionTotal = transactionTotal;
	}

	/**
	 * @return the transactionCount
	 */
	public final long getTransactionCount() {
		return transactionCount;
	}

	/**
	 * @param transactionCount the transactionCount to set
	 */
	public final void setTransactionCount(long transactionCount) {
		this.transactionCount = transactionCount;
	}

	/**
	 * @return the title
	 */
	public final String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public final void setTitle(String title) {
		this.title = title;
	}

	public String toListString() {
		return  
	String.format("%10d  %d-%02d-%02d  %17s  %10d  %11d  %18.3f  %-25s\n",
			transactionID, year, month, day,credit_card_no, cust_SSN,branch_code, 
			transactionValue,  transactionType) ;
	}

	public String getBillingList() {
		return String.format("%-10d  %d-%02d-%02d  %11d  %18.3f  %-25s\n",
				transactionID, year, month, day, branch_code, transactionValue,  transactionType) ;
			
	}




	public Transaction() {
		super();
	}
	public Transaction(String title) {
		this.title = title;
	}
	
	public Transaction(Transaction tr) {
		this.transactionID = tr.transactionID;
		this.day = tr.day;
		this.month = tr.month;
		this.year = tr.year;
		this.credit_card_no = tr.credit_card_no;
		this.cust_SSN = tr.cust_SSN;
		this.branch_code = tr.branch_code;
		this.transactionType = tr.transactionType;
		this.transactionValue = tr.transactionValue;
		this.transactionTotal = tr.transactionTotal;
		this.transactionCount = tr.transactionCount;
		this.title = tr.title;
	}

	@Override
	public String toString() {
		return "Transaction Information " + title + "\n" +
	           "Transaction ID \t : " + transactionID + "\n" +
	           "Year  \t \t : " + year + "\n" +
			   "Month \t \t : " + month + "\n" + 
			   "Day  \t \t : " + day + "\n" + 
			   "Creadit_card_no  : " +   credit_card_no + "\n" + 
			   "Cust_SSN \t : " + cust_SSN  + "\n" + 
			   "Branch_code\t : " + branch_code + "\n" +
			   "Transaction type : " + transactionType + "\n" + 
			   "Transaction Value: " + transactionValue + "\n\n";
	}
	
}
