package com.cdw.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.cdw.constants.Queries;
import com.cdw.constants.ViewData;
import com.cdw.exceptions.DBConfigException;
import com.cdw.model.Transaction;

/**
 * 
 * @author AO
 * Data Access Object for Credit card transaction
 *
 */
public class TransactionDAO extends ConnectionDAO {

	/**
	 * 
	 * @param ZipCode - Transaction Zip code 
	 * @param year    - Transaction year
	 * @param month   -  Transaction month
	 * @return  List of transaction for the giving zip code and period
	 * @see
	 * DBConfigException
	 */
	public ArrayList<Transaction> 
		getTransactionByZipCode(String ZipCode, int year, int month) throws DBConfigException{
		
		establishConnection();
		String query = Queries.GET_TRANSACTION_BY_ZIPCODE;
		ArrayList<Transaction> transactions=null;
		String tTitle = "Transaction list for ZipCode:" + ZipCode + " Mont/Year:"  +String.format("%02d/%d", month,year)   ;
		
		try {
			state = conn.prepareStatement(query);
			state.setString(1, ZipCode);
			state.setInt(2, year);
			state.setInt(3, month);
			result = state.executeQuery();
			Transaction trBills=null;
			
			while(result.next()) {
			
				if(transactions == null) {
					transactions = new ArrayList<Transaction> ();
				}
				
				Transaction transaction = new Transaction(tTitle);
				transaction = setQueryResult(transaction);
				transactions.add(transaction);
				/*
				 *  Content the total value of the list of transaction 
				 *  and the number of transaction selected for a giving customer
				 */
					if(trBills == null) { 
						trBills = new Transaction(transaction);
						trBills.setTransactionCount(1);
						trBills.setTransactionTotal(transaction.getTransactionValue()); 
						trBills.setTransactionType("Total for ZipCode:" + ZipCode + " - "  +String.format("%2d/%d", month,year));
					} else {
						trBills.setTransactionTotal(trBills.getTransactionTotal() + transaction.getTransactionValue());
						trBills.setTransactionCount(trBills.getTransactionCount() + 1);
					}
			}
			/*
			 * Register the #Transaction and TansactionTotal at the end of the list 
			 */
			if(trBills != null) {
				trBills.setTransactionValue(trBills.getTransactionTotal());
				trBills.setBranch_code((int)trBills.getTransactionCount());
				transactions.add(trBills);
			}
			if(transactions == null) {
				throw new  DBConfigException("No transaction found for Zipcode# " + ZipCode +
						" and period of " + String.format("%02d/%d", month,year), "DATABASE EXCEPTIION") ;
			}
		}  catch (SQLException e) {
			throw new  DBConfigException(e.getMessage(), e, "DATABASE EXCEPTIION") ;
		} finally {
			closeConnection();
		}
		
		return transactions;
	} //public ArrayList<Transaction> getTransactionByZipCode(

	
	/**
	 * 
	 * @param transState - Code du State
	 * @return - The statistic Number and total credit card transaction for the 
	 * giving state.
	 * @see DBConfigException
	 */
	public StringBuilder getTransactionNumTotByState(String transState)
			throws DBConfigException {
		
		establishConnection();
		String query = Queries.GET_TRANSACTION_NUM_TOT_BY_STATE;
		StringBuilder transactions=null;
		String defaultStr = "";
		try {
			state = conn.prepareStatement(query);
			state.setString(1, transState);
			result = state.executeQuery();
			int iRow = 0;
			long TOT_COUNT = 0;
			double TOT_TOTAL= 0;
			while(result.next()) {
				if(transactions == null) {
					transactions = new StringBuilder();
				}
				iRow++;
				String transactionState= result.getString(1);
				String branch_code     = result.getString(2);
				long TRANSACTION_COUNT = result.getLong(3);
				double TRANSACTION_TOTAL= result.getDouble(4);
				if(iRow == 1) {
				      transactions.append(
				    	   "Number and Total value of transaction for branches by state \n" +  
						   "Transaction State      : " + transactionState + "\n" +
						   "Branch code            : " + branch_code + "\n" +	   
						   "Number of Transaction  : " + TRANSACTION_COUNT + "\n" +
						   "Transaction total value: " + TRANSACTION_TOTAL + "\n\n");
				      defaultStr =
				    	"Number and Total value of transaction by branch \n \n" +
				        String.format("%11s    %12s    %10s    %18s\n", "State", "Branch_Code", "#Transaction", 
				        		"Transaction total") +
				        ViewData.LINE_S_WIDTH.substring(3) + 
				        String.format("%11s    %12s    %10s    %18.3f\n", transactionState, branch_code,
				    		  TRANSACTION_COUNT, TRANSACTION_TOTAL);
				      TOT_COUNT +=TRANSACTION_COUNT;
				      TOT_TOTAL +=TRANSACTION_TOTAL;
				} else {
					if(iRow == 2) {
					   transactions = new StringBuilder(defaultStr);
					}
					transactions.append(String.format("%11s    %12s    %10s    %18.3f\n", transactionState, branch_code,
			    		  TRANSACTION_COUNT, TRANSACTION_TOTAL));
				}
			   }
    		 if(iRow >= 2) {
    	 		   	transactions.append(String.format(ViewData.LINE_S_WIDTH.substring(3)));	
    	 			transactions.append(String.format("%29S  %10d    %18.3f\n","TOTAL " + transState,  TOT_COUNT, TOT_TOTAL));	
	          }
    		 if(transactions == null) {
 				throw new  DBConfigException("No transaction found for State " + transState, "DATABASE EXCEPTIION") ;
 			}
			 } catch (SQLException e) {
				 throw new  DBConfigException(e.getMessage(), e, "DATABASE EXCEPTIION") ;
			 } finally {
				closeConnection();
			 }
		return transactions;
		} //public void getTransactionNumTotByType
	
	
public StringBuilder getTransactionNumTotByType(String transType) throws DBConfigException {
		
		establishConnection();
		String query = Queries.GET_TRANSACTION_NUM_TOT_BY_TYPE;
		StringBuilder transactions=null;
		
		try {
			state = conn.prepareStatement(query);
			state.setString(1, transType);
			result = state.executeQuery();
			
			if(result.next()) {
				transactions = new StringBuilder();
				
				String transactionType = result.getString(1);
				long TRANSACTION_COUNT = result.getLong(2);
				double TRANSACTION_TOTAL  = result.getDouble(3);
				transactions.append(
						   "Number and Total value of transaction by type \n" +
						   "Transaction type        : " + transactionType + "\n" +
						   "Number of Transaction   : " + TRANSACTION_COUNT + "\n" +
						   "Transaction total value : " + TRANSACTION_TOTAL + "\n\n");  
				
			   }
			if(transactions == null) {
				throw new  DBConfigException("No transaction found for TransactionType " + transType, "DATABASE EXCEPTIION") ;
			}
			 } catch (SQLException e) {
				 throw new  DBConfigException(e.getMessage(), e, "DATABASE EXCEPTIION") ;
			 } finally {
					closeConnection();
			 }
		return transactions;
		} //public void getTransactionNumTotByType



public ArrayList<Transaction> 
getCustomerBillsByMonth(String creditCard, int year, int month) throws DBConfigException{


	establishConnection();
	String query = Queries.GET_CUSTOMER_BILLS_BY_MONTH;
	ArrayList<Transaction> transactions=null;
	String tTitle = "Billing info for Month/Year: " + month  + "/" + year;
	
	try {
		state = conn.prepareStatement(query);
		state.setString(1, creditCard);
		state.setInt(2, year);
		state.setInt(3, month);
		result = state.executeQuery();
		Transaction trBills = null;
		
		while(result.next()) {
			/* TRANSACTION_ID, DAY, MONTH, YEAR,  CREDIT_CARD_NO, CUST_SSN, BRANCH_CODE, 
			 * TRANSACTION_TYPE, TRANSACTION_VALUE 
			 */
			if(transactions == null) {
				transactions = new ArrayList<Transaction> ();
			}
			
			int transactionID = result.getInt(1);
			int dayT = result.getInt(2);
			int monthT  = result.getInt(3);
			int yearT = result.getInt(4);
			String credit_Card_No = result.getString(5);
			int cust_SSN = result.getInt(6);
			int branch_code = result.getInt(7);
			String transactionType = result.getString(8);
			double transactionValue = result.getDouble(9);
			
			Transaction transaction = new Transaction(tTitle);
			transaction.setTransactionID(transactionID);
			transaction.setDay(dayT);
			transaction.setMonth(monthT);
			transaction.setYear(yearT);
			transaction.setCredit_card_no(credit_Card_No);
			transaction.setCust_SSN(cust_SSN);
			transaction.setBranch_code(branch_code);
			transaction.setTransactionType(transactionType);
			transaction.setTransactionValue(transactionValue);
			transactions.add(transaction);
			if(trBills == null) { // Content the total bill of the customer
				trBills = new Transaction(transaction);
				trBills.setTransactionCount(1);
				trBills.setTransactionTotal(transaction.getTransactionValue());
				trBills.setTransactionType("Total Bill " + month + "/"+ year + "");
			} else {
				trBills.setTransactionTotal(trBills.getTransactionTotal() + transaction.getTransactionValue());
				trBills.setTransactionCount(trBills.getTransactionCount() + 1);
			}
		}
		if(trBills != null) {
			trBills.setTransactionValue(trBills.getTransactionTotal());
			trBills.setBranch_code((int)trBills.getTransactionCount());
			transactions.add(trBills);
		}
		if(transactions == null) {
			throw new  DBConfigException("No transaction found for CrediCard# " + creditCard +
					" and period of " + String.format("%02d/%d", month,year), "DATABASE EXCEPTIION") ;
		}
	}  catch (SQLException e) {
		throw new  DBConfigException(e.getMessage(), e, "DATABASE EXCEPTIION") ;
	} finally {
		closeConnection();
	}
	
	return transactions;
} //public ArrayList<Transaction> getCustomerBillsByMonth(


/*
 * Get the list of transactions made by a customer between two dates. 
 * The query is Order by year month, and day in descending order.
 * @Param: ssn for Social Security Number
 *        startDate for the star date of the selection
 *        endDate for the end date of the selection
 */
public ArrayList<Transaction> 
        getCustomerTransactionByPeriode(String ssn, Date startDate, Date endDate) throws DBConfigException {
	
	establishConnection();
	/* The query to execute in order to get a customer the list 
	 * of transactions between two dates
	 */
	String query = Queries.GET_CUSTOMER_TRANSACT_BY_PERIODE;
	
	//Will content the list of selected transactions
	ArrayList<Transaction> transactions=null;
	
	// Specific title to display on the screen
	String tTitle = "Transaction list from : " + startDate  + " to " + endDate;
	Calendar cal = Calendar.getInstance();
	cal.setTime(startDate);
	int yStart = cal.get(Calendar.YEAR),
	    mStart = cal.get(Calendar.MONTH)+ 1,
		dStart = cal.get(Calendar.DAY_OF_MONTH);
	cal.setTime(endDate);
	int yEnd = cal.get(Calendar.YEAR),
		mEnd = cal.get(Calendar.MONTH) + 1,
		dEnd = cal.get(Calendar.DAY_OF_MONTH);
	
	String startD = String.format("%d-%02d-%02d",yStart,mStart,dStart);
	String endD =   String.format("%d-%02d-%02d",yEnd,mEnd,dEnd);
	try {
		tTitle = "Transaction list from : " + startD  + " to " + endD;
		state = conn.prepareStatement(query);
		state.setString(1, ssn);
		state.setString(2, startD);
		state.setString(3, endD);
		result = state.executeQuery();
		Transaction trBills = null;
		
		while(result.next()) {
			if(transactions == null) {
				transactions = new ArrayList<Transaction> ();
			}
			
			Transaction transaction = new Transaction(tTitle);
			transaction = setQueryResult(transaction);
			transactions.add(transaction);
		/*
		 *  Content the total value of the list of transaction 
		 *  and the number of transaction selected for a giving customer
		 */
			if(trBills == null) { 
				trBills = new Transaction(transaction);
				trBills.setTransactionCount(1);
				trBills.setTransactionTotal(transaction.getTransactionValue());
				trBills.setTransactionType("Total  " + startDate + " to "+ endDate + "");
			} else {
				trBills.setTransactionTotal(trBills.getTransactionTotal() + transaction.getTransactionValue());
				trBills.setTransactionCount(trBills.getTransactionCount() + 1);
			}
		}
		/*
		 * Register the #Transaction and TansactionTotal at the end of the list 
		 */
		if(trBills != null) {
			trBills.setTransactionValue(trBills.getTransactionTotal());
			trBills.setBranch_code((int)trBills.getTransactionCount());
			transactions.add(trBills);
		}
		if(transactions == null) {
			throw new  DBConfigException("No transaction found for SSN# " + ssn +
					" from " + startD  + " to " + endD, "DATABASE EXCEPTIION") ;
		}
	}  catch (SQLException e) {
		throw new  DBConfigException(e.getMessage(), e, "DATABASE EXCEPTIION") ;
	} finally {
		closeConnection();
	}
	
	return transactions;
}

/**
 * Set the transaction record from the query result
 * @param transaction
 * @return Transaction record
 * @see
 * @{@link SQLException}
 */
private Transaction setQueryResult(Transaction transaction) throws SQLException {


	transaction.setTransactionID(result.getInt("transaction_ID"));  
	transaction.setDay(result.getInt("day"));
	transaction.setMonth(result.getInt("month"));
	transaction.setYear(result.getInt("year"));
	transaction.setCredit_card_no(result.getString("credit_card_no"));
	transaction.setCust_SSN(result.getInt("cust_SSN"));
	transaction.setBranch_code(result.getInt("branch_code"));
	transaction.setTransactionType(result.getString("transaction_Type"));
	transaction.setTransactionValue( result.getDouble("transaction_Value"));
	
	return transaction;
}
	
	
}
