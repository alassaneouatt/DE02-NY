package com.cdw.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cdw.exceptions.DBConfigException;

/**
 * <pre>
 * Establish or close database connection
 * The system will establish the connection to the current database defined in DBProperties
 * If the current database is not defined, the system will throw DBConfigException
 * </pre>
 * @author AO
 * @see DBConfigException - Extends {@link DBConfigException}
 *      DBProperties - {@link DBProperties} 
 * 			  DBProperties.getInstance()
 * 			  currentDBavailable()
 *            getDriver()
 *            getUrl(), 
 *			  getUser(), 
 *			  getPassword())
 *   
 */
public abstract class ConnectionDAO {
	
	protected Connection conn = null;
	protected PreparedStatement state = null;
	protected ResultSet result = null;
	
	
	/**
	 * <pre>
	 * Establish the connection to the current database
	 * @throws DBConfigException
	 */
	protected void establishConnection()  throws DBConfigException {
			//Properties content DB parameters
			if (DBProperties.getInstance().currentDBavailable()) {
				try {
					Class.forName(DBProperties.getInstance().getDriver()); 
				} catch (ClassNotFoundException e) {
					throw new DBConfigException(
							"Incorrect or missing database driver in classpath: \n" + 
							 DBProperties.getInstance().getDriver());
				}

				try {
					conn = DriverManager.getConnection(
							DBProperties.getInstance().getUrl(), 
							DBProperties.getInstance().getUser(), 
							DBProperties.getInstance().getPassword());
				} catch (SQLException e) {
					throw new DBConfigException(
				        	"Database connection failed.\n" + 
	                		"Incorrect url or user login.");
				}
			} else {
				throw new DBConfigException(
		                "No parameter was set up in properties file " + 
		                		DBProperties.getInstance().getPropertiesFile() + "'.");
			}
	
	}
	
	/**
	 * <pre>
	 * Close the current database connection
	 * @throws DBConfigException
	 */
	protected void closeConnection() {
		if(conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				throw new DBConfigException(
						"Fail over database connection. " + e.getMessage() ,e,
				"Closing Database connection error");
			}
		}
	}
}
