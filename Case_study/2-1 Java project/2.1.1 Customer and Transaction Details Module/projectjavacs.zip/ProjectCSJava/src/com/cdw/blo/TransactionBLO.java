package com.cdw.blo;

import java.util.ArrayList;
import java.util.Date;

import com.cdw.dao.TransactionDAO;
import com.cdw.model.Transaction;

public class TransactionBLO {
	
	private static TransactionDAO transactionDAO = new TransactionDAO();
	private static TransactionBLO instance = new TransactionBLO();
	private TransactionBLO() {};
	public static TransactionBLO getInstance() {
		return instance ;
	}

	public ArrayList<Transaction> 
	   getCustomerTransactionByPeriode(String ssn, Date startDate, Date endDate) {
		
		return transactionDAO.getCustomerTransactionByPeriode(ssn, startDate, endDate);
	}
	
	public ArrayList<Transaction> 
	    getCustomerBillsByMonth(String creditCard, int year, int month) {
		// TODO Auto-generated method stub
		return transactionDAO.getCustomerBillsByMonth(creditCard, year, month);
	}
	
	public StringBuilder getTransactionNumTotByState(String transState) {
		// TODO Auto-generated method stub
		return transactionDAO.getTransactionNumTotByState(transState);
	}
	
	public StringBuilder getTransactionNumTotByType(String transType) {
		// TODO Auto-generated method stub
		return transactionDAO. getTransactionNumTotByType(transType);
	}
	
	public ArrayList<Transaction> 
	    getTransactionByZipCode(String zipcode, int year, int month) {
		
		return transactionDAO.getTransactionByZipCode(zipcode, year, month);
	}

}
