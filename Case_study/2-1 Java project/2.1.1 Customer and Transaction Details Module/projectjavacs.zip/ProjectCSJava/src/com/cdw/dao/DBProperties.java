package com.cdw.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import com.cdw.exceptions.DBConfigException;

import java.util.Properties;

/**
 * #summary Manage the content of the properties file
 * This class check and load the properties files.
 * <p>
 * The name of the properties is <b>db.properties</b>. It is located in the classpath, 
 * and contains the parameters of your databases.
 * <p> 
 * You can define one or more database parameter in the properties.
 * In case of multiple databases, the system will give you an option to select the database 
 * you want to connect to.
 * <b>db.properties</b> content for each database should be in the formatted as below:
 * <ul>
 * <li><b>databaseName.driver=driverValue</b></li>
 * <li><b>databaseName.url=urlValue</b></li>
 * <li><b>databaseName.user=userValue</b></li>
 * <li><b>databaseName.password=passwordValue</b></li>
 * </ul>
 * Parameter is <b>case sensitive. So, driver, url, user, password</b> should be in lower case 
 * For instance my database <b>HOME_CDW_SAPP</b> will be configured as below
 * <ul>
 * <li>HOME_CDW_SAPP.driver=com.mysql.jdbc.Driver</li>
 * <li>HOME_CDW_SAPP.url=jdbc:mysql://localhost:3306/CDW_SAPP?useSSL=false</li>
 * <li>HOME_CDW_SAPP.user=springstudent</li>
 * <li>HOME_CDW_SAPP.password=Springstudent</li>
 * </ul>
 * @author Alassane Ouattara (AO)
 * @see DBConfigException 
 */
public class DBProperties  {
	private static final String PROPERTIES_FILE = "db.properties";
	private static final Properties MY_PROPERTIES = new Properties();
	private String databaseName=""; 
	private String url; 
	private String driver; 
	private String user; 
	private String password; 
	
	private static DBProperties instance = new DBProperties();
	private DBProperties() {};
	/**
	 * 
	 * @return An instance of the properties file. 
	 * That instance will allow you to manage the properties file parameters
	 */
	public static DBProperties getInstance() {
		return instance ;
	}
	/**
	 * 
	 * @return Properties file name
	 */
	public String getPropertiesFile() {
		return PROPERTIES_FILE;
	}
	
	/**
	 * 
	 * @return  False if no database has been set to current.
	 */
	public boolean currentDBavailable() {
		
		return !databaseName.equals("");
	}
	/**
	 * 
	 * @return The current database name. If no database has been assigned yet,
	 * the system will throw DBConfigException 
	 * 
	 */
	public String getCurrentDatabaseName()  throws DBConfigException {
		if (databaseName.equals("")) {
			throw new DBConfigException(
	                "No current database has been defined yet.",
	                "Database selection error");
		}
		return databaseName;
	}
	/**
	 * @param databaseName
	 * Set the giving database name as the current database.
	 * Update the database parameters: <b>driver, url, user, password</b>
	 * 
	 */
	public void setCurrentDatabaseName(String databaseName)  throws DBConfigException {
		if(MY_PROPERTIES.isEmpty()) {
			throw new DBConfigException(
	                "No parameter was found in properties file '" + PROPERTIES_FILE + "'.",
	                "Database configuration error");
		} else if (MY_PROPERTIES.getProperty(databaseName+".driver")==null) {
			throw new DBConfigException(
	               "'" + databaseName + "' <driver> parameter is missing in properties file '" + PROPERTIES_FILE + "'.",
	                "Database configuration error");
		}else if (MY_PROPERTIES.getProperty(databaseName+".url")==null) {
			throw new DBConfigException(
		               "'" + databaseName + "' <url> parameter is missing in properties file '" + PROPERTIES_FILE + "'.",
		                "Database configuration error");
		}else if (MY_PROPERTIES.getProperty(databaseName+".user")==null) {
			throw new DBConfigException(
		               "'" + databaseName + "' <user> parameter is missing in properties file '" + PROPERTIES_FILE + "'.",
		                "Database configuration error");
		}else if (MY_PROPERTIES.getProperty(databaseName+".password")==null) {
			throw new DBConfigException(
		               "'" + databaseName + "' <password> parameter is missing in properties file '" + PROPERTIES_FILE + "'.",
		                "Database configuration error");
		}
		
		this.driver 	= MY_PROPERTIES.getProperty(databaseName+".driver");
		this.url		= MY_PROPERTIES.getProperty(databaseName+".url");
		this.user		= MY_PROPERTIES.getProperty(databaseName+".user");
		this.password	= MY_PROPERTIES.getProperty(databaseName+".password");
		this.databaseName= databaseName;
	}
	

	public String getUrl() {
		return url;
	}
	public String getDriver() {
		return driver;
	}
	public String getUser() {
		return user;
	}
	public String getPassword() {
		return password;
	}
	/**
	 * The method get the list of database defined in the properties files
	 * @return : List of databases. If the properties files is not correctly configured
	 * 			the system will throw an exception
	 * {@literal} DBConfigException
	 */
	public List<String> getDatabases() throws DBConfigException{
		
		HashSet<String>
		     myDBList = null;
		checkPropertiesFile();
		
		Iterator<Entry<Object, Object>> itPropList = MY_PROPERTIES.entrySet().iterator();
		while (itPropList.hasNext()) {
			if(myDBList == null) {
				 myDBList = new HashSet<>();
			}
			String key = (String) itPropList.next().getKey();
			int i = key.indexOf(".");
			if( i != -1) myDBList.add(key.substring(0, i));
		}
		if(myDBList == null) {
			throw new DBConfigException(
	                "Properties file '" + PROPERTIES_FILE + "' is empty." + 
	                "\nYou should define the parameters of your database.",
	                "Database parameters error");
		} else if (myDBList.isEmpty()) {
			throw new DBConfigException(
	                "Properties file '" + PROPERTIES_FILE + "' is not correctly formatted." +
	                "\nYour database parameter should be like 'databaseName.param1=param1Value'." +
	                "\nFor instance driver parameter can be 'CDW_SAPP.driver=com.mysql.jdbc.Driver'.",
	                "Database parameters error");
		}
		List<String> myList = new ArrayList<>();
		myList.addAll(myDBList);
		return myList;
	}
	/**
	 * Check if the properties files is in the classpath
	 * If not send an error message
	 * otherwise load the properties file 
	 */
	private void checkPropertiesFile() throws DBConfigException {
		FileInputStream pFile;
		try {
			pFile = new FileInputStream(
				      this.getClass().getClassLoader()
				      .getResource("db.properties")
				      .getFile()
				);
		} catch (FileNotFoundException e1) {
			throw new DBConfigException(
	                "Properties file '" + PROPERTIES_FILE + "' not found in classpath.\n" +
			e1.toString(),e1,
	                "Database configuration error");
		}
		 catch (NullPointerException e1) {
				throw new DBConfigException(
		                "Properties file '" + PROPERTIES_FILE + "' not found in classpath.\n" +
		                e1.toString(),e1,
		                "Database configuration error");
			}
		try {
			 // loads the file from the input stream into MY_PROPERTIES object
			 MY_PROPERTIES.load(pFile);
		}	 
		 catch (IOException e) {
			throw new DBConfigException(
	                "Cannot load the properties file '" + PROPERTIES_FILE + "'.\n"+ 
	                e.toString(), e,
	                "Database configuration error");
		}
	}
}
