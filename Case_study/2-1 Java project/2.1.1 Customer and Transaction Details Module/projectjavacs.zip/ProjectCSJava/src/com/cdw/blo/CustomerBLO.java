package com.cdw.blo;

import java.util.List;

import com.cdw.dao.CustomerDAO;
import com.cdw.exceptions.DBConfigException;
import com.cdw.model.Customer;

/**
 * <pre>
 * Customer business logic object.
 * Call the data access object in order to request data from
 * the database.
 * All customer data request from the view layer will go 
 * throughout this object to the data access object.
 * @author AO
 * 
 */
public class CustomerBLO {
	private static CustomerDAO customerDAO = new CustomerDAO();
	private static CustomerBLO instance = new CustomerBLO();
	private CustomerBLO() {};
	public static CustomerBLO getInstance() {
		return instance ;
	}
	
	/**
	 * @param SSN: Social Security Number
	 * This method will return a list of customer data .
	 * 
	 */
	public List<Customer> getCustomerBySSN(int cust_SSN) throws DBConfigException  {
		
		return customerDAO.getCustomerBySSN(cust_SSN);
	}
	
	/**
	 *<pre> Save the customer information into the database.
	 * @param customer - Customer record
	 * 
	 */
	public void saveCustomer(Customer customer)  throws DBConfigException {
		
		customerDAO.saveCustomer(customer);
	}
}
