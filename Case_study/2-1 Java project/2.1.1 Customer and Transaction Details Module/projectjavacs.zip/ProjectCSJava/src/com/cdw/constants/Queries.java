package com.cdw.constants;

/**
 * 
 * @author AO
 *
 */
public class Queries {
	public final static String 
		GET_CUSTOMER_BY_SSN 		  = "SELECT * FROM CDW_SAPP_CUSTOMER WHERE SSN = ?";
	public final static String 
	       GET_TRANSACTION_BY_ZIPCODE =
			"SELECT  tc.TRANSACTION_ID,  tc.DAY, tc.MONTH, tc.YEAR, tc.CREDIT_CARD_NO, tc.CUST_SSN, " +
					"tc.BRANCH_CODE, tc.TRANSACTION_TYPE, tc.TRANSACTION_VALUE, cust.cust_ZIP  " +
			"FROM cdw_sapp_creditcard  tc JOIN cdw_sapp_customer cust on cust.SSN = tc.CUST_SSN " +
			"WHERE cust.CUST_ZIP = ? AND tc.year = ? AND tc.MONTH = ? ORDER BY DAY desc ";
	public final static String 
	       GET_TRANSACTION_NUM_TOT_BY_TYPE =
	       "SELECT TRANSACTION_TYPE, COUNT(TRANSACTION_ID) TRANSACTION_COUNT, " +
	       "       SUM(TRANSACTION_VALUE) TRANSACTION_TOTAL" + 
	       " FROM cdw_sapp_creditcard WHERE TRANSACTION_TYPE = ? " + 
	       " GROUP BY TRANSACTION_TYPE ORDER BY TRANSACTION_TYPE";
	public final static String 
    	GET_TRANSACTION_NUM_TOT_BY_STATE =
	       "SELECT br.BRANCH_STATE, br.BRANCH_CODE," + 
	       "       COUNT(tc.TRANSACTION_ID) TRANSACTION_COUNT,  " + 
	       "       SUM(tc.TRANSACTION_VALUE) TRANSACTION_TOTAL " + 
	       " FROM cdw_sapp_creditcard  tc  " + 
	       " JOIN cdw_sapp_branch br USING(BRANCH_CODE) " + 
	       " WHERE br.BRANCH_STATE = ? " + 
	       " GROUP BY  br.BRANCH_CODE " + 
	       " ORDER BY br.BRANCH_STATE, br.BRANCH_CODE";
	
	public final static String
		SET_CUSTOMER_BY_SSN = 
		   "UPDATE CDW_SAPP_CUSTOMER " +
		   "SET CUST_STATE = ?,  STREET_NAME = ?,  CUST_COUNTRY = ?,  CUST_CITY = ?,  FIRST_NAME = ?, " + 
		   "MIDDLE_NAME = ?,  LAST_NAME = ?,  CUST_EMAIL = ?,  APT_NO = ?,  CUST_PHONE = ?, CUST_ZIP = ? "  +
		   "WHERE  SSN = ?";
	public final static String
	     GET_CUSTOMER_BILLS_BY_MONTH =
	     "SELECT TRANSACTION_ID, DAY, MONTH, YEAR, CREDIT_CARD_NO, CUST_SSN, " + 
	     "BRANCH_CODE, TRANSACTION_TYPE, TRANSACTION_VALUE " + 
	     "FROM cdw_sapp_creditcard  " + 
	     "WHERE CREDIT_CARD_NO =  ? " + 
	     " AND   YEAR = ? AND MONTH =  ? " + 
	     "ORDER BY CREDIT_CARD_NO, YEAR, MONTH ";
	
	public final static String
    GET_CUSTOMER_TRANSACT_BY_PERIODE =
    "SELECT TRANSACTION_ID, DAY, MONTH, YEAR, CREDIT_CARD_NO, CUST_SSN, " + 
    "BRANCH_CODE, TRANSACTION_TYPE, TRANSACTION_VALUE " + 
    "FROM cdw_sapp_creditcard  " + 
    "WHERE CUST_SSN =  ? " + 
    " AND   DATE(CONCAT(YEAR,'-',MONTH,'-',DAY)) BETWEEN ?  AND ? " + 
    "ORDER BY YEAR DESC , MONTH DESC, DAY DESC ";
	
	
	private Queries() {
		// TO PREVENT NEW INSTANCE DE QUERIES
	}
}
