package com.cdw.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.cdw.model.Customer;

public class EroorTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerService obj = new CustomerService();

        try {

            Customer cus = obj.findByName("t");

        } catch (NameNotFoundException e) {
          // e.printStackTrace();
        	System.out.println(e.getMessage());
        	System.out.println(e.getCause().getStackTrace());
        }
        
        
        CustomerService obj2 = new CustomerService();

		//create 100 size
        List<String> data = new ArrayList<>(Collections.nCopies(100, "mkyong"));

        obj2.analyze(data);

	}

}
