package com.cdw.model;

public class Customer {

	private String creditCardNo;
	private String state;
	private String streetName;
	private String country;
	private String city;
	private String fName;
	private String mName;
	private String lName;
	private String email;
	private String zip;
	private String aptN;
	private int ssn;
	private int phone;
	private double transactionTotal;
	private long transactionCount;
	
	public double getTransactionTotal() {
		return transactionTotal;
	}

	public void setTransactionTotal(double transactionTotal) {
		this.transactionTotal = transactionTotal;
	}

	public long getTransactionCount() {
		return transactionCount;
	}

	public void setTransactionCount(long transactionCount) {
		this.transactionCount = transactionCount;
	}

	public Customer() {
		super();
	}

	public Customer(Customer cust) {
		this.creditCardNo = cust.creditCardNo;
		this.state = cust.state;
		this.streetName = cust.streetName;
		this.country = cust.country;
		this.city = cust.city;
		this.fName = cust.fName;
		this.mName = cust.mName;
		this.lName = cust.lName;
		this.email = cust.email;
		this.zip = cust.zip;
		this.aptN = cust.aptN;
		this.ssn = cust.ssn;
		this.phone = cust.phone;
	}
	
	public String getCreditCardNo() {
		return creditCardNo;
	}
	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getAptN() {
		return aptN;
	}
	public void setAptN(String aptN) {
		this.aptN = aptN;
	}
	public int getSsn() {
		return ssn;
	}
	public void setSsn(int ssn) {
		this.ssn = ssn;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return 
				"Customer Information" + "\n" +
				"First Name \t: " + fName + "\n" + 
				"Middle Name\t: " + mName + "\n" + 
				"Last Name \t: " + lName + "\n" + 
				"SSN  \t \t: " + ssn + "\n" + 
				"creditCardNo  \t: " + creditCardNo + "\n" + 
				"State \t \t: " + state + "\n" + 
				"StreetName \t: " + streetName + "\n" +
				"Country \t: " + country + "\n" + 
				"City \t \t: " + city + "\n" + 
				"Email \t \t: " + email + "\n" + 
				"Zip \t \t: " + zip + "\n" + 
				"AptN \t \t: " + aptN + "\n" + 
				"Phone \t \t: " + phone + "\n";
	}
	
	
	public String toViewString() {
		return 
				"Customer Information" + "\n" +
				String.format("%1$-17s:  %2$s\n", "First Name ", fName) +
				String.format("%1$-17s:  %2$s\n", "Middle Name ", mName) +
				String.format("%1$-17s:  %2$s\n", "Last Name ", lName) +
				String.format("%1$-17s:  %2$s\n", "SSN ", ssn) +
				String.format("%1$-17s:  %2$s\n", "creditCardNo", creditCardNo) +
				String.format("%1$-17s:  %2$s\n", "State ", state) +
				String.format("%1$-17s:  %2$s\n", "StreetName", streetName) +
				String.format("%1$-17s:  %2$s\n", "Country", country) +
				String.format("%1$-17s:  %2$s\n", "City", city) +
				String.format("%1$-17s:  %2$s\n", "Email", email) +
				String.format("%1$-17s:  %2$s\n", "Zip", zip) +
				String.format("%1$-17s:  %2$s\n", "AptN", aptN) +
				String.format("%1$-17s:  %2$s\n", "Phone", phone) + "\n";
	}
	public String customerToBills() {
	return	String.format("%1$-21s:  %2$s\n", "Full Name ", fName + " " + mName + " " + lName) +
		String.format("%1$-21s:  %2$s\n", "Address",  aptN + ", " + streetName + ", " + city + ", " + state + " " + zip + " " + country) +
		String.format("%1$-21s:  %2$s\n", "Email", email) +
		String.format("%1$-21s:  %2$s\n", "Phone", phone) +
		String.format("%1$-21s:  %2$d\n",  "#Tansaction", transactionCount) +
		String.format("%1$-21s:  %2$-18.3f\n","Total Bill",transactionTotal);
	}

	public String SelectFieldToEdit() {
		return 
				"Customer Information" + "\n" +
				String.format("%1$-21s:  %2$s\n", " 1) First Name ", fName) +
				String.format("%1$-21s:  %2$s\n", " 2) Middle Name ", mName) +
				String.format("%1$-21s:  %2$s\n", " 3) Last Name ", lName) +
				String.format("%1$-21s:  %2$s\n", " 4) SSN ", ssn) +
				String.format("%1$-21s:  %2$s\n", " 5) creditCardNo", creditCardNo) +
				String.format("%1$-21s:  %2$s\n", " 6) State ", state) +
				String.format("%1$-21s:  %2$s\n", " 7) StreetName", streetName) +
				String.format("%1$-21s:  %2$s\n", " 8) Country", country) +
				String.format("%1$-21s:  %2$s\n", " 9) City", city) +
				String.format("%1$-21s:  %2$s\n", "10) Email", email) +
				String.format("%1$-21s:  %2$s\n", "11) Zip", zip) +
				String.format("%1$-21s:  %2$s\n", "12) AptN", aptN) +
				String.format("%1$-21s:  %2$s\n", "13) Phone", phone) + "\n";
		
	}
	
}
