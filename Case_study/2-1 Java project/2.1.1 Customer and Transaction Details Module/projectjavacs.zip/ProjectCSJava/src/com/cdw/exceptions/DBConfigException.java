package com.cdw.exceptions;

public class DBConfigException extends RuntimeException {

	/**
	 * This class will handle exception related to the configuration of the database
	 * Properties files .... 
	 */
	private static final long serialVersionUID = 1L;
    private String ExceptionTitle="";
    
	public String getExceptionTitle() {
		return ExceptionTitle;
	}

	public DBConfigException(String message, Throwable cause, String title) {
		super(message, cause);
		this.ExceptionTitle = title;
	}

	public DBConfigException(String message) {
		super(message);
	}
	
	public DBConfigException(String message, String title) {
		super(message);
		this.ExceptionTitle = title;
	}

	public DBConfigException(Throwable cause) {
		super(cause);
	}

	


}
