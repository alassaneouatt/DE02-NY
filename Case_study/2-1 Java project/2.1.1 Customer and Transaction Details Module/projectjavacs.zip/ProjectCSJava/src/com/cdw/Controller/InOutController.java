package com.cdw.Controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.cdw.constants.ViewData;

public class InOutController {

	private static final int MAX_WIDTH = 120; 
	private static InOutController instance = new InOutController();
	private InOutController() {}
		
	public static InOutController getInstance() {
		// TODO Auto-generated method stub
		return instance;
	}

	public StringBuilder listToMenu(List<String> myList) {
		StringBuilder sb = new StringBuilder();
		
		int i =0;
		for (String m : myList) {
			sb.append(String.format("%3s)  %s \n", ++i,m));
		}
		return sb;
	}
	
	public Date getDateValue(String dateValue, String dFromat){
		   SimpleDateFormat dateFormat = new SimpleDateFormat(dFromat);
		 	
			if(dateValue == null || dateValue.isEmpty()){
				System.out.println("Invalid date value " + dateValue);
				return null;
			}
			// parse the date only. Does not add the time
			dateFormat.setLenient(false);
		
			try {
				return dateFormat.parse(dateValue);
			} catch (ParseException e) {
				System.out.println("Invalid date value " + e.getMessage());
				return null;
			}
		}


	public boolean isValidDateValue(String dateValue, String dFromat){
		   SimpleDateFormat dateFormat = new SimpleDateFormat(dFromat);
		
			if(dateValue == null || dateValue.isEmpty()){
				System.out.println("Invalid date value " + dateValue);
				return false;
			}
			// parse the date only. Does not add the time
			dateFormat.setLenient(false);
		
			try {
				dateFormat.parse(dateValue);
			} catch (ParseException e) {
				System.out.println("Invalid date value " + e.getMessage());
				return false;
			}
			return true;
		}
		
	public StringBuilder textToDisplay(String text, String title) {
		return textToDisplay(text,title,0);
	}
	
	public StringBuilder textToDisplay(String text, String title, int iTypeLine) {
		return textToDisplay(text,title,iTypeLine,"|");
	}
	
	
	public StringBuilder textToDisplay(String text, String title, int iTypeLine,String columnBar) {
		StringBuilder sb = new StringBuilder();
		String line= title, lineType;
		columnBar = columnBar.trim();
		switch(iTypeLine) {
			case 1:
				lineType = ViewData.LINE_TILDE;
				break;
			case 2:
				lineType = ViewData.LINE_D_WIDTH;
				break;
			case 3:
				lineType = ViewData.LINE_DD_WIDTH;
				break;
			case 4:
				lineType = ViewData.LINE_LD_WIDTH;
				break;	
			case 5:
				lineType = ViewData.LINE_X_WIDTH;
				break;
				
			default:
				lineType = ViewData.LINE_S_WIDTH;
				break;
		}
		int pos = ((MAX_WIDTH - title.length() -1) / 2) - 1;
		if(pos<0) {pos=0;}
		line = lineType.substring(0, pos) + " " + title + " " +
			   lineType.substring(pos + title.length() + 2); // for the 2 blank char
		sb.append(line) ;
		String[] splitText = text.split("\n");
		for(int i=0;i<splitText.length;i++) {
			line= columnBar + " " + splitText[i];
			if (line.length() < MAX_WIDTH) {
				line = line + ViewData.LINE_BLANK_WIDTH.substring(line.length(), MAX_WIDTH ) +  columnBar + "\n"; 
			} else {
				line = line + "\n";
			}
			sb.append(line) ;
		}
		sb.append(lineType) ;
		return sb;
	}
	
	
  }

